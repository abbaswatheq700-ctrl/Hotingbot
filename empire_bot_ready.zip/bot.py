# -*- coding: utf-8 -*-
"""
إمبراطورية عظمى - بوت لعبة اقتصادية واستراتيجية لتيليغرام
Python 3.10+
المكتبات: pyTelegramBotAPI
قاعدة البيانات: SQLite (تُحفظ محلياً في empire.db)
"""
import os
import sqlite3
import time
import json
import random
import threading
from datetime import datetime, timedelta

import telebot
from telebot import types

# ==================== الإعدادات الأساسية ====================
BOT_TOKEN = "8911350186:AAH-fkkqCrolal4YvPwfHpdn3cuBSQuwCFY"
ADMIN_SECRET_CODE = "ABSIRQ17MAR"
DB_PATH = os.getenv("EMPIRE_DB_PATH", "empire.db")
STARTING_CASH = 2500
DAILY_REWARD = 700
WORK_COOLDOWN_SECONDS = 60 * 30
DAILY_COOLDOWN_SECONDS = 60 * 60 * 20
MAX_COMPANIES = 10
MAX_PROPERTIES = 30

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML", threaded=True)
db_lock = threading.RLock()
admin_sessions = set()
pending_admin_action = {}
pending_trade = {}
pending_alliance = {}
pending_broadcast = set()

# ==================== قاعدة البيانات ====================
def connect():
    con = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db_lock, connect() as con:
        con.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS players(
            user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
            cash INTEGER NOT NULL DEFAULT 2500, bank INTEGER NOT NULL DEFAULT 0,
            level INTEGER NOT NULL DEFAULT 1, xp INTEGER NOT NULL DEFAULT 0,
            reputation INTEGER NOT NULL DEFAULT 0, last_daily INTEGER NOT NULL DEFAULT 0,
            last_work INTEGER NOT NULL DEFAULT 0, jailed_until INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS properties(
            id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL,
            kind TEXT NOT NULL, name TEXT NOT NULL, cost INTEGER NOT NULL,
            income INTEGER NOT NULL, level INTEGER NOT NULL DEFAULT 1,
            last_collect INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS companies(
            id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL,
            name TEXT NOT NULL, kind TEXT NOT NULL, cost INTEGER NOT NULL,
            income INTEGER NOT NULL, level INTEGER NOT NULL DEFAULT 1,
            last_collect INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS inventory(
            user_id INTEGER NOT NULL, item TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(user_id,item)
        );
        CREATE TABLE IF NOT EXISTS alliances(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL,
            leader_id INTEGER NOT NULL, treasury INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS alliance_members(
            alliance_id INTEGER NOT NULL, user_id INTEGER UNIQUE NOT NULL,
            role TEXT NOT NULL DEFAULT 'عضو', joined_at INTEGER NOT NULL,
            PRIMARY KEY(alliance_id,user_id)
        );
        CREATE TABLE IF NOT EXISTS settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
            action TEXT NOT NULL, detail TEXT, created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS admin_ids(user_id INTEGER PRIMARY KEY, created_at INTEGER NOT NULL);
        """)
        defaults = {
            "maintenance": "0", "daily_reward": str(DAILY_REWARD),
            "starting_cash": str(STARTING_CASH), "work_reward_min": "100",
            "work_reward_max": "350", "tax_percent": "5",
            "property_income_multiplier": "1", "announcement": "",
            "new_players_enabled": "1", "transfer_enabled": "1",
            "economy_multiplier": "1", "game_name": "إمبراطورية عظمى"
        }
        for k, v in defaults.items():
            con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

def setting(key, default=""):
    with db_lock, connect() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

def set_setting(key, value):
    with db_lock, connect() as con:
        con.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

def log_action(user_id, action, detail=""):
    with db_lock, connect() as con:
        con.execute("INSERT INTO logs(user_id,action,detail,created_at) VALUES(?,?,?,?)",
                    (user_id, action, str(detail)[:1000], int(time.time())))

def get_player(user):
    uid = user.id
    with db_lock, connect() as con:
        row = con.execute("SELECT * FROM players WHERE user_id=?", (uid,)).fetchone()
        if row:
            con.execute("UPDATE players SET username=?,first_name=? WHERE user_id=?",
                        (user.username or "", user.first_name or "", uid))
            return dict(row)
        if setting("new_players_enabled", "1") != "1":
            return None
        cash = int(setting("starting_cash", STARTING_CASH))
        con.execute("""INSERT INTO players(user_id,username,first_name,cash,created_at)
                       VALUES(?,?,?,?,?)""", (uid, user.username or "", user.first_name or "", cash, int(time.time())))
        con.execute("INSERT OR IGNORE INTO inventory(user_id,item,quantity) VALUES(?,?,0)", (uid, "قمح"))
        log_action(uid, "register", f"starting_cash={cash}")
        return dict(con.execute("SELECT * FROM players WHERE user_id=?", (uid,)).fetchone())

def player_by_id(uid):
    with db_lock, connect() as con:
        row = con.execute("SELECT * FROM players WHERE user_id=?", (uid,)).fetchone()
        return dict(row) if row else None

def change_money(uid, cash_delta=0, bank_delta=0):
    with db_lock, connect() as con:
        row = con.execute("SELECT cash,bank FROM players WHERE user_id=?", (uid,)).fetchone()
        if not row: return False
        if row["cash"] + cash_delta < 0 or row["bank"] + bank_delta < 0: return False
        con.execute("UPDATE players SET cash=cash+?,bank=bank+? WHERE user_id=?", (cash_delta, bank_delta, uid))
        return True

def money(n):
    return f"{int(n):,} 💰"

def main_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    buttons = [
        "👤 ملفي", "💰 الاقتصاد", "🏪 السوق", "🏰 أملاكي",
        "🏭 شركاتي", "🏦 البنك", "🎁 المكافآت", "⚒️ العمل",
        "🤝 التحالفات", "🏆 المتصدرون", "🎒 حقيبتي", "📜 المهام",
        "⚔️ المغامرة", "❓ المساعدة"
    ]
    kb.add(*[types.KeyboardButton(x) for x in buttons])
    return kb

def inline(rows):
    kb = types.InlineKeyboardMarkup()
    for row in rows:
        kb.row(*[types.InlineKeyboardButton(text, callback_data=data) for text, data in row])
    return kb

def safe_send(chat_id, text, **kwargs):
    try:
        bot.send_message(chat_id, text, **kwargs)
    except Exception as e:
        print("send error:", e)

def is_admin(uid):
    with db_lock, connect() as con:
        return con.execute("SELECT 1 FROM admin_ids WHERE user_id=?", (uid,)).fetchone() is not None

def admin_panel_markup():
    return inline([
        [("📊 إحصائيات اللعبة", "adm:stats"), ("⚙️ إعدادات الاقتصاد", "adm:economy")],
        [("💸 تغيير المكافأة اليومية", "adm:daily"), ("🪙 رصيد لاعب", "adm:money")],
        [("📣 إذاعة رسالة", "adm:broadcast"), ("🔧 صيانة البوت", "adm:maintenance")],
        [("👥 قائمة اللاعبين", "adm:players"), ("📜 آخر السجلات", "adm:logs")],
        [("🎮 إعدادات اللعبة", "adm:game"), ("🚫 تفعيل/إيقاف التسجيل", "adm:registration")],
        [("💱 تفعيل/إيقاف التحويلات", "adm:transfers"), ("📢 إعلان عام", "adm:announcement")],
        [("🔒 إغلاق اللوحة", "adm:close")]
    ])

def admin_home(chat_id):
    bot.send_message(chat_id,
        "👑 <b>لوحة تحكم الإمبراطورية</b>\nتحكم بالإعدادات والاقتصاد واللاعبين والإعلانات والصيانة.\n\n"
        "اختر العملية من الأزرار:", reply_markup=admin_panel_markup())

@bot.message_handler(commands=["start"])
def start(message):
    p = get_player(message.from_user)
    if p is None:
        bot.reply_to(message, "⛔ التسجيل متوقف حالياً من الإدارة.")
        return
    announcement = setting("announcement", "")
    text = (f"👑 أهلاً بك في <b>{setting('game_name','إمبراطورية عظمى')}</b>!\n\n"
            f"أنت تبدأ رحلتك ومعك {money(p['cash'])}.\n"
            "كوّن ثروتك، اشترِ العقارات، أسّس الشركات، واصنع إمبراطوريتك الخاصة!\n\n"
            "استخدم الأزرار للعب. اكتب /admin لفتح بوابة الإدارة.")
    if announcement: text += f"\n\n📢 <b>إعلان الإدارة:</b>\n{announcement}"
    bot.send_message(message.chat.id, text, reply_markup=main_menu())

@bot.message_handler(commands=["help"])
def help_cmd(message):
    bot.reply_to(message, help_text(), reply_markup=main_menu())

def help_text():
    return ("📖 <b>دليل الإمبراطورية</b>\n"
            "• 💰 الاقتصاد: رصيدك، التحويلات، وشراء/بيع الموارد.\n"
            "• 🏪 السوق: شراء عقارات وشركات.\n"
            "• 🏰 أملاكي / 🏭 شركاتي: تحصيل الأرباح والترقية.\n"
            "• 🏦 البنك: إيداع وسحب الأموال.\n"
            "• 🎁 المكافآت: مكافأة يومية.\n"
            "• ⚒️ العمل: كسب المال كل 30 دقيقة.\n"
            "• 🤝 التحالفات: إنشاء تحالف أو الانضمام إليه.\n"
            "• ⚔️ المغامرة: مغامرة عشوائية بمكافأة أو خسارة.\n"
            "• 📜 المهام: إنجاز مهام يومية بسيطة.\n"
            "• /profile: عرض ملفك، /top: المتصدرون، /admin: لوحة الإدارة.\n"
            "ملاحظة: اللعبة افتراضية، والأموال داخلها ليست أموالاً حقيقية.")

@bot.message_handler(commands=["profile"])
def profile_cmd(message):
    p = get_player(message.from_user)
    if p: show_profile(message.chat.id, p)

def show_profile(chat_id, p):
    with db_lock, connect() as con:
        props = con.execute("SELECT COUNT(*) c FROM properties WHERE owner_id=?", (p["user_id"],)).fetchone()["c"]
        companies = con.execute("SELECT COUNT(*) c FROM companies WHERE owner_id=?", (p["user_id"],)).fetchone()["c"]
        alliance = con.execute("""SELECT a.name,m.role FROM alliance_members m JOIN alliances a ON a.id=m.alliance_id
                                  WHERE m.user_id=?""", (p["user_id"],)).fetchone()
    xp_needed = p["level"] * 250
    text = (f"👤 <b>ملف {p['first_name'] or p['username'] or p['user_id']}</b>\n\n"
            f"🆔 المعرف: <code>{p['user_id']}</code>\n"
            f"💰 النقد: {money(p['cash'])}\n🏦 البنك: {money(p['bank'])}\n"
            f"⭐ المستوى: {p['level']} | الخبرة: {p['xp']}/{xp_needed}\n"
            f"🎖 السمعة: {p['reputation']}\n🏰 العقارات: {props}/{MAX_PROPERTIES}\n"
            f"🏭 الشركات: {companies}/{MAX_COMPANIES}\n"
            f"🤝 التحالف: {alliance['name'] if alliance else 'بدون تحالف'}")
    bot.send_message(chat_id, text, reply_markup=main_menu())

@bot.message_handler(commands=["top"])
def top_cmd(message):
    show_top(message.chat.id)

def show_top(chat_id):
    with db_lock, connect() as con:
        rows = con.execute("SELECT user_id,first_name,username,cash+bank AS wealth,level FROM players ORDER BY wealth DESC LIMIT 10").fetchall()
    if not rows:
        bot.send_message(chat_id, "ماكو لاعبين بعد.")
        return
    text = "🏆 <b>أغنى 10 أباطرة</b>\n\n"
    for i, r in enumerate(rows, 1):
        name = r["first_name"] or (("@"+r["username"]) if r["username"] else str(r["user_id"]))
        text += f"{i}. {name} — {money(r['wealth'])} | مستوى {r['level']}\n"
    bot.send_message(chat_id, text)

@bot.message_handler(commands=["admin"])
def admin_cmd(message):
    bot.send_message(message.chat.id, "🔐 أرسل الكود السري لفتح لوحة الإدارة.\nإذا ما كنت مسؤولاً، لا تحاول تخمينه.")
    pending_admin_action[message.from_user.id] = ("auth", None)

@bot.message_handler(commands=["cancel"])
def cancel_cmd(message):
    uid = message.from_user.id
    pending_admin_action.pop(uid, None)
    pending_broadcast.discard(uid)
    bot.reply_to(message, "تم إلغاء العملية.", reply_markup=main_menu())

@bot.callback_query_handler(func=lambda c: c.data.startswith("adm:"))
def admin_callbacks(call):
    uid = call.from_user.id
    if not is_admin(uid):
        bot.answer_callback_query(call.id, "غير مصرح لك.", show_alert=True)
        return
    action = call.data.split(":", 1)[1]
    bot.answer_callback_query(call.id)
    if action == "close":
        admin_sessions.discard(uid)
        bot.send_message(call.message.chat.id, "تم إغلاق لوحة الإدارة.")
    elif action == "stats":
        with db_lock, connect() as con:
            users = con.execute("SELECT COUNT(*) c FROM players").fetchone()["c"]
            cash = con.execute("SELECT COALESCE(SUM(cash),0) c FROM players").fetchone()["c"]
            bank = con.execute("SELECT COALESCE(SUM(bank),0) c FROM players").fetchone()["c"]
            props = con.execute("SELECT COUNT(*) c FROM properties").fetchone()["c"]
            comps = con.execute("SELECT COUNT(*) c FROM companies").fetchone()["c"]
            alliances = con.execute("SELECT COUNT(*) c FROM alliances").fetchone()["c"]
        bot.send_message(call.message.chat.id, f"📊 <b>إحصائيات الإمبراطورية</b>\nاللاعبون: {users}\nالنقد المتداول: {money(cash)}\nأموال البنوك: {money(bank)}\nالعقارات: {props}\nالشركات: {comps}\nالتحالفات: {alliances}\nالصيانة: {setting('maintenance')}")
    elif action == "economy":
        bot.send_message(call.message.chat.id,
            f"⚙️ <b>إعدادات الاقتصاد الحالية</b>\nالمكافأة اليومية: {setting('daily_reward')}\n"
            f"أجر العمل: {setting('work_reward_min')}–{setting('work_reward_max')}\nالضريبة: {setting('tax_percent')}%\nمضاعف الاقتصاد: {setting('economy_multiplier')}\n\n"
            "أرسل أحد الأوامر التالية:\n<code>daily 1000</code>\n<code>work 200 500</code>\n<code>tax 3</code>\n<code>multiplier 1.5</code>")
        pending_admin_action[uid] = ("economy", None)
    elif action == "daily":
        bot.send_message(call.message.chat.id, "أرسل قيمة المكافأة اليومية الجديدة (رقم موجب).")
        pending_admin_action[uid] = ("daily", None)
    elif action == "money":
        bot.send_message(call.message.chat.id, "أرسل: <code>معرف_اللاعب المبلغ</code> لإضافة المبلغ، أو مبلغ سالب لخصمه.")
        pending_admin_action[uid] = ("money", None)
    elif action == "broadcast":
        bot.send_message(call.message.chat.id, "أرسل نص الإذاعة. اكتب /cancel للإلغاء.")
        pending_broadcast.add(uid)
    elif action == "maintenance":
        new = "0" if setting("maintenance") == "1" else "1"
        set_setting("maintenance", new)
        bot.send_message(call.message.chat.id, "🔧 الصيانة: " + ("مفعلة" if new == "1" else "متوقفة"))
    elif action == "players":
        with db_lock, connect() as con:
            rows = con.execute("SELECT user_id,first_name,username,cash,level FROM players ORDER BY created_at DESC LIMIT 30").fetchall()
        out = "👥 <b>آخر 30 لاعباً</b>\n"
        for r in rows:
            out += f"\n{r['first_name'] or r['username'] or 'لا اسم'} | <code>{r['user_id']}</code> | {money(r['cash'])} | L{r['level']}"
        bot.send_message(call.message.chat.id, out[:4000])
    elif action == "logs":
        with db_lock, connect() as con:
            rows = con.execute("SELECT user_id,action,detail,created_at FROM logs ORDER BY id DESC LIMIT 20").fetchall()
        out = "📜 <b>آخر السجلات</b>\n"
        for r in rows:
            out += f"\n{datetime.fromtimestamp(r['created_at']).strftime('%m-%d %H:%M')} | {r['user_id']} | {r['action']} | {r['detail']}"
        bot.send_message(call.message.chat.id, out[:4000])
    elif action == "game":
        bot.send_message(call.message.chat.id,
            f"🎮 اسم اللعبة: {setting('game_name')}\nرصيد البداية: {setting('starting_cash')}\n"
            "أرسل <code>name اسم اللعبة</code> أو <code>startcash 5000</code>.")
        pending_admin_action[uid] = ("game", None)
    elif action == "registration":
        new = "0" if setting("new_players_enabled") == "1" else "1"
        set_setting("new_players_enabled", new)
        bot.send_message(call.message.chat.id, "التسجيل: " + ("مفتوح" if new == "1" else "متوقف"))
    elif action == "transfers":
        new = "0" if setting("transfer_enabled") == "1" else "1"
        set_setting("transfer_enabled", new)
        bot.send_message(call.message.chat.id, "التحويلات: " + ("مفتوحة" if new == "1" else "متوقفة"))
    elif action == "announcement":
        bot.send_message(call.message.chat.id, "أرسل نص الإعلان العام، أو اكتب <code>off</code> لحذفه.")
        pending_admin_action[uid] = ("announcement", None)

@bot.message_handler(func=lambda m: True, content_types=["text"])
def text_router(message):
    uid = message.from_user.id
    text = (message.text or "").strip()
    # Route pending alliance/trade inputs before the catch-all handler consumes them.
    if uid in pending_trade:
        trade_text(message)
        return
    # authentication / admin pending actions
    pending = pending_admin_action.get(uid)
    if pending:
        action, _ = pending
        if action == "auth":
            if text == ADMIN_SECRET_CODE:
                with db_lock, connect() as con:
                    con.execute("INSERT OR IGNORE INTO admin_ids(user_id,created_at) VALUES(?,?)", (uid, int(time.time())))
                admin_sessions.add(uid)
                pending_admin_action.pop(uid, None)
                log_action(uid, "admin_login", "secret-code")
                admin_home(message.chat.id)
            else:
                pending_admin_action.pop(uid, None)
                bot.reply_to(message, "❌ الكود غير صحيح.")
                log_action(uid, "admin_auth_failed", "")
            return
        if action == "economy":
            parts = text.split()
            try:
                if len(parts) == 2 and parts[0] == "daily":
                    val = int(parts[1]); assert val >= 0
                    set_setting("daily_reward", val); reply = f"تم تغيير المكافأة اليومية إلى {val}."
                elif len(parts) == 3 and parts[0] == "work":
                    lo, hi = int(parts[1]), int(parts[2]); assert 0 <= lo <= hi
                    set_setting("work_reward_min", lo); set_setting("work_reward_max", hi); reply = "تم تحديث أجر العمل."
                elif len(parts) == 2 and parts[0] == "tax":
                    val = int(parts[1]); assert 0 <= val <= 50
                    set_setting("tax_percent", val); reply = f"تم ضبط الضريبة على {val}%."
                elif len(parts) == 2 and parts[0] == "multiplier":
                    val = float(parts[1]); assert 0 <= val <= 100
                    set_setting("economy_multiplier", val); reply = f"تم ضبط مضاعف الاقتصاد على {val}."
                else: raise ValueError()
                bot.reply_to(message, "✅ " + reply)
            except Exception:
                bot.reply_to(message, "صيغة غير صحيحة. أمثلة: daily 1000 | work 200 500 | tax 5 | multiplier 1.5")
            pending_admin_action.pop(uid, None); return
        if action == "daily":
            try:
                val = int(text); assert val >= 0
                set_setting("daily_reward", val); bot.reply_to(message, f"تم ضبط المكافأة اليومية: {money(val)}")
            except Exception: bot.reply_to(message, "أرسل رقماً صحيحاً موجباً.")
            pending_admin_action.pop(uid, None); return
        if action == "money":
            try:
                target, amount = map(int, text.split()[:2])
                if not player_by_id(target): raise ValueError()
                with db_lock, connect() as con:
                    con.execute("UPDATE players SET cash=MAX(0,cash+?) WHERE user_id=?", (amount, target))
                log_action(uid, "admin_money", f"target={target},amount={amount}")
                bot.reply_to(message, "تم تعديل رصيد اللاعب.")
            except Exception: bot.reply_to(message, "الصيغة: معرف_اللاعب المبلغ")
            pending_admin_action.pop(uid, None); return
        if action == "game":
            try:
                if text.startswith("name "):
                    set_setting("game_name", text[5:].strip()[:80]); bot.reply_to(message, "تم تغيير اسم اللعبة.")
                elif text.startswith("startcash "):
                    val = int(text.split()[1]); assert val >= 0
                    set_setting("starting_cash", val); bot.reply_to(message, "تم تغيير رصيد اللاعبين الجدد.")
                else: raise ValueError()
            except Exception: bot.reply_to(message, "استخدم: name اسم اللعبة أو startcash 5000")
            pending_admin_action.pop(uid, None); return
        if action == "announcement":
            set_setting("announcement", "" if text.lower() == "off" else text[:1000])
            bot.reply_to(message, "تم تحديث الإعلان.")
            pending_admin_action.pop(uid, None); return
    if uid in pending_broadcast:
        pending_broadcast.discard(uid)
        with db_lock, connect() as con:
            ids = [r["user_id"] for r in con.execute("SELECT user_id FROM players").fetchall()]
        sent = 0
        for target in ids:
            try:
                bot.send_message(target, "📣 <b>إعلان الإدارة</b>\n\n" + text[:3500])
                sent += 1
                time.sleep(0.04)
            except Exception:
                pass
        bot.reply_to(message, f"انتهت الإذاعة. تم الإرسال إلى {sent} من {len(ids)} لاعباً.")
        log_action(uid, "broadcast", f"sent={sent}")
        return

    # Maintenance mode exempts administrators
    if setting("maintenance") == "1" and not is_admin(uid) and text not in ("/start", "/help"):
        bot.reply_to(message, "🔧 الإمبراطورية تحت الصيانة حالياً. حاول لاحقاً.")
        return
    p = get_player(message.from_user)
    if p is None:
        bot.reply_to(message, "التسجيل متوقف حالياً.")
        return
    if text in ("👤 ملفي", "ملفي"):
        show_profile(message.chat.id, p)
    elif text in ("💰 الاقتصاد", "الاقتصاد"):
        bot.send_message(message.chat.id,
            f"💰 <b>اقتصادك</b>\nالنقد: {money(p['cash'])}\nالبنك: {money(p['bank'])}\n"
            "للتحويل: <code>تحويل معرف_اللاعب المبلغ</code>\n"
            "للإيداع: <code>ايداع المبلغ</code>\nللسحب: <code>سحب المبلغ</code>")
    elif text.startswith("تحويل "):
        if setting("transfer_enabled") != "1":
            bot.reply_to(message, "التحويلات متوقفة من الإدارة."); return
        try:
            target, amount = map(int, text.split()[1:3])
            if target == uid or amount <= 0: raise ValueError()
            fee = int(amount * int(setting("tax_percent", "5")) / 100)
            with db_lock, connect() as con:
                con.execute("BEGIN IMMEDIATE")
                sender = con.execute("SELECT cash FROM players WHERE user_id=?", (uid,)).fetchone()
                receiver = con.execute("SELECT user_id FROM players WHERE user_id=?", (target,)).fetchone()
                if not receiver or not sender or sender["cash"] < amount + fee:
                    con.rollback(); raise ValueError()
                con.execute("UPDATE players SET cash=cash-? WHERE user_id=?", (amount+fee, uid))
                con.execute("UPDATE players SET cash=cash+? WHERE user_id=?", (amount, target))
                con.commit()
            bot.reply_to(message, f"تم تحويل {money(amount)} إلى اللاعب {target}. الضريبة: {money(fee)}.")
            safe_send(target, f"💸 استلمت {money(amount)} من اللاعب {uid}.")
            log_action(uid, "transfer", f"target={target},amount={amount},fee={fee}")
        except Exception: bot.reply_to(message, "فشل التحويل. تأكد من الصيغة والرصيد ومعرف اللاعب.")
    elif text.startswith("ايداع ") or text.startswith("إيداع "):
        try:
            amount = int(text.split()[1])
            if amount <= 0 or not change_money(uid, -amount, amount): raise ValueError()
            bot.reply_to(message, f"🏦 أودعت {money(amount)}.")
        except Exception: bot.reply_to(message, "ما عندك رصيد كافي أو المبلغ غير صحيح.")
    elif text.startswith("سحب "):
        try:
            amount = int(text.split()[1])
            if amount <= 0 or not change_money(uid, amount, -amount): raise ValueError()
            bot.reply_to(message, f"🏦 سحبت {money(amount)}.")
        except Exception: bot.reply_to(message, "ما عندك رصيد كافي بالبنك أو المبلغ غير صحيح.")
    elif text in ("🏦 البنك", "البنك"):
        bot.send_message(message.chat.id, f"🏦 <b>البنك الإمبراطوري</b>\nرصيد البنك: {money(p['bank'])}\nاكتب: ايداع 500 أو سحب 500")
    elif text in ("🎁 المكافآت", "المكافآت"):
        now = int(time.time())
        if now - p["last_daily"] < DAILY_COOLDOWN_SECONDS:
            remain = DAILY_COOLDOWN_SECONDS - (now - p["last_daily"])
            bot.reply_to(message, f"⏳ المكافأة متاحة بعد {remain//3600} ساعة و{(remain%3600)//60} دقيقة.")
        else:
            reward = int(int(setting("daily_reward", DAILY_REWARD)) * float(setting("economy_multiplier", "1")))
            with db_lock, connect() as con:
                con.execute("UPDATE players SET cash=cash+?,last_daily=?,xp=xp+50,reputation=reputation+1 WHERE user_id=?", (reward, now, uid))
            bot.reply_to(message, f"🎁 استلمت مكافأتك اليومية: {money(reward)} و50 خبرة.")
    elif text in ("⚒️ العمل", "العمل"):
        now = int(time.time())
        if now - p["last_work"] < WORK_COOLDOWN_SECONDS:
            remain = WORK_COOLDOWN_SECONDS - (now-p["last_work"])
            bot.reply_to(message, f"⏳ تگدر تشتغل بعد {remain//60} دقيقة.")
        else:
            reward = random.randint(int(setting("work_reward_min","100")), int(setting("work_reward_max","350")))
            reward = int(reward * float(setting("economy_multiplier","1")))
            with db_lock, connect() as con:
                con.execute("UPDATE players SET cash=cash+?,last_work=?,xp=xp+20 WHERE user_id=?", (reward, now, uid))
            bot.reply_to(message, f"⚒️ خلصت شغلك وربحت {money(reward)} و20 خبرة.")
    elif text in ("🏪 السوق", "السوق"):
        show_market(message.chat.id, uid)
    elif text in ("🏰 أملاكي", "أملاكي"):
        show_properties(message.chat.id, uid)
    elif text in ("🏭 شركاتي", "شركاتي"):
        show_companies(message.chat.id, uid)
    elif text in ("🤝 التحالفات", "التحالفات"):
        show_alliances(message.chat.id, uid)
    elif text in ("🏆 المتصدرون", "المتصدرون"):
        show_top(message.chat.id)
    elif text in ("🎒 حقيبتي", "حقيبتي"):
        with db_lock, connect() as con:
            rows = con.execute("SELECT item,quantity FROM inventory WHERE user_id=? AND quantity>0", (uid,)).fetchall()
        bot.send_message(message.chat.id, "🎒 <b>حقيبتك</b>\n" + ("\n".join(f"• {r['item']}: {r['quantity']}" for r in rows) if rows else "حقيبتك فارغة حالياً."))
    elif text in ("📜 المهام", "المهام"):
        bot.send_message(message.chat.id, "📜 <b>مهامك الحالية</b>\n1. ادخل يومياً وخذ المكافأة.\n2. اشتغل وارفع خبرتك.\n3. اشترِ عقاراً أو شركة.\n4. انضم إلى تحالف.\n\nالمهام المتقدمة قيد التوسعة.")
    elif text in ("⚔️ المغامرة", "المغامرة"):
        adventure(message.chat.id, uid, p)
    elif text in ("❓ المساعدة", "/help"):
        bot.send_message(message.chat.id, help_text(), reply_markup=main_menu())
    elif text.startswith("/"):
        bot.reply_to(message, "أمر غير معروف. اكتب /help.")
    else:
        bot.send_message(message.chat.id, "اختار من القائمة أو اكتب /help.", reply_markup=main_menu())

PROPERTIES = [
    ("🏚️ كوخ", "كوخ", 1000, 40),
    ("🏠 منزل", "منزل", 5000, 220),
    ("🏢 شقة فاخرة", "شقة فاخرة", 15000, 700),
    ("🏬 مجمع تجاري", "مجمع تجاري", 50000, 2600),
    ("🏨 فندق", "فندق", 120000, 7000),
    ("🏰 قصر إمبراطوري", "قصر إمبراطوري", 500000, 32000),
    ("🌾 مزرعة", "مزرعة", 8000, 350),
    ("⛏️ منجم", "منجم", 35000, 1800),
]
COMPANIES = [
    ("🥖 مخبز", "مخبز", 2500, 130),
    ("🍽️ مطعم", "مطعم", 10000, 550),
    ("🛒 متجر", "متجر", 18000, 950),
    ("🚚 شركة نقل", "شركة نقل", 40000, 2100),
    ("🏭 مصنع", "مصنع", 90000, 5200),
    ("💻 شركة تقنية", "شركة تقنية", 200000, 12500),
    ("🏦 مصرف", "مصرف", 450000, 30000),
    ("🛢️ شركة نفط", "شركة نفط", 1000000, 72000),
]

def show_market(chat_id, uid):
    rows = []
    for label, kind, cost, income in PROPERTIES:
        rows.append([(f"{label} — {money(cost)}", f"buyprop:{kind}")])
    rows.append([("🏭 عرض الشركات", "market:companies")])
    bot.send_message(chat_id, "🏪 <b>السوق الإمبراطوري</b>\nاشترِ عقارات تدر أرباحاً دورية أو افتح قسم الشركات.", reply_markup=inline(rows))

@bot.callback_query_handler(func=lambda c: c.data.startswith("buyprop:"))
def buy_property(call):
    uid = call.from_user.id; kind = call.data.split(":",1)[1]
    p = player_by_id(uid)
    item = next((x for x in PROPERTIES if x[1] == kind), None)
    if not p or not item:
        bot.answer_callback_query(call.id, "خطأ."); return
    label, kind, cost, income = item
    with db_lock, connect() as con:
        count = con.execute("SELECT COUNT(*) c FROM properties WHERE owner_id=?", (uid,)).fetchone()["c"]
        if count >= MAX_PROPERTIES or p["cash"] < cost:
            bot.answer_callback_query(call.id, "الرصيد غير كافٍ أو وصلت للحد الأقصى.", show_alert=True); return
        con.execute("UPDATE players SET cash=cash-?,xp=xp+30 WHERE user_id=?", (cost, uid))
        con.execute("INSERT INTO properties(owner_id,kind,name,cost,income,last_collect) VALUES(?,?,?,?,?,?)",
                    (uid, kind, kind, cost, income, int(time.time())))
    bot.answer_callback_query(call.id, "تم الشراء بنجاح!")
    bot.send_message(call.message.chat.id, f"🎉 اشتريت {kind}! دخلها الأساسي {money(income)} كل 6 ساعات.")

@bot.callback_query_handler(func=lambda c: c.data == "market:companies")
def market_companies(call):
    rows = [[(f"{label} — {money(cost)}", f"buycomp:{kind}")] for label,kind,cost,income in COMPANIES]
    bot.answer_callback_query(call.id)
    bot.send_message(call.message.chat.id, "🏭 <b>سوق الشركات</b>\nكل شركة تنتج أرباحاً دورية.", reply_markup=inline(rows))

@bot.callback_query_handler(func=lambda c: c.data.startswith("buycomp:"))
def buy_company(call):
    uid = call.from_user.id; kind = call.data.split(":",1)[1]
    p = player_by_id(uid)
    item = next((x for x in COMPANIES if x[1] == kind), None)
    if not p or not item:
        bot.answer_callback_query(call.id, "خطأ."); return
    label, kind, cost, income = item
    with db_lock, connect() as con:
        count = con.execute("SELECT COUNT(*) c FROM companies WHERE owner_id=?", (uid,)).fetchone()["c"]
        if count >= MAX_COMPANIES or p["cash"] < cost:
            bot.answer_callback_query(call.id, "الرصيد غير كافٍ أو وصلت للحد الأقصى.", show_alert=True); return
        con.execute("UPDATE players SET cash=cash-?,xp=xp+50 WHERE user_id=?", (cost, uid))
        con.execute("INSERT INTO companies(owner_id,name,kind,cost,income,last_collect) VALUES(?,?,?,?,?,?)",
                    (uid, kind, kind, cost, income, int(time.time())))
    bot.answer_callback_query(call.id, "تم تأسيس الشركة!")
    bot.send_message(call.message.chat.id, f"🏭 أسست {kind}! دخلها الأساسي {money(income)} كل 6 ساعات.")

@bot.callback_query_handler(func=lambda c: c.data.startswith("prop:"))
def property_callbacks(call):
    uid = call.from_user.id
    action = call.data.split(":")[1]
    try: item_id = int(call.data.split(":")[2])
    except: bot.answer_callback_query(call.id); return
    with db_lock, connect() as con:
        row = con.execute("SELECT * FROM properties WHERE id=? AND owner_id=?", (item_id, uid)).fetchone()
        if not row: bot.answer_callback_query(call.id, "هذا العقار مو إلك."); return
        now = int(time.time())
        if action == "collect":
            elapsed = now - row["last_collect"]
            periods = min(8, elapsed // (6*3600))
            if periods < 1:
                bot.answer_callback_query(call.id, "الأرباح بعد ما جاهزة.", show_alert=True); return
            amount = int(row["income"] * row["level"] * periods * float(setting("property_income_multiplier","1")) * float(setting("economy_multiplier","1")))
            tax = int(amount * int(setting("tax_percent","5")) / 100)
            con.execute("UPDATE players SET cash=cash+? WHERE user_id=?", (amount-tax, uid))
            con.execute("UPDATE properties SET last_collect=? WHERE id=?", (now, item_id))
            log_action(uid, "collect_property", f"id={item_id},amount={amount-tax}")
            bot.answer_callback_query(call.id, f"جمعت {amount-tax}!")
            bot.send_message(call.message.chat.id, f"💰 دخل العقار: {money(amount-tax)} بعد ضريبة {money(tax)}.")
        elif action == "upgrade":
            cost = row["cost"] * row["level"]
            player = con.execute("SELECT cash FROM players WHERE user_id=?", (uid,)).fetchone()
            if player["cash"] < cost:
                bot.answer_callback_query(call.id, f"تحتاج {money(cost)}.", show_alert=True); return
            con.execute("UPDATE players SET cash=cash-? WHERE user_id=?", (cost, uid))
            con.execute("UPDATE properties SET level=level+1,income=income*2 WHERE id=?", (item_id,))
            bot.answer_callback_query(call.id, "تم تطوير العقار!")
            bot.send_message(call.message.chat.id, f"⬆️ تم تطوير {row['name']} للمستوى {row['level']+1}.")

def show_properties(chat_id, uid):
    with db_lock, connect() as con:
        rows = con.execute("SELECT * FROM properties WHERE owner_id=? ORDER BY id DESC", (uid,)).fetchall()
    if not rows:
        bot.send_message(chat_id, "ما عندك عقارات. افتح 🏪 السوق وابدأ استثمارك."); return
    for r in rows[:20]:
        elapsed = int(time.time()) - r["last_collect"]
        periods = min(8, elapsed // (6*3600))
        ready = r["income"] * r["level"] * periods
        kb = inline([[("💰 تحصيل الأرباح", f"prop:collect:{r['id']}"), ("⬆️ تطوير", f"prop:upgrade:{r['id']}")]])
        bot.send_message(chat_id, f"{r['name']} | المستوى {r['level']}\nالدخل لكل 6 ساعات: {money(r['income']*r['level'])}\nأرباح جاهزة تقريباً: {money(ready)}", reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data.startswith("comp:"))
def company_callbacks(call):
    uid = call.from_user.id
    action, rawid = call.data.split(":")[1:3]
    try: item_id = int(rawid)
    except: bot.answer_callback_query(call.id); return
    with db_lock, connect() as con:
        row = con.execute("SELECT * FROM companies WHERE id=? AND owner_id=?", (item_id, uid)).fetchone()
        if not row: bot.answer_callback_query(call.id, "الشركة مو إلك."); return
        now = int(time.time())
        if action == "collect":
            periods = min(8, (now-row["last_collect"]) // (6*3600))
            if periods < 1:
                bot.answer_callback_query(call.id, "الأرباح بعد ما جاهزة.", show_alert=True); return
            amount = int(row["income"] * row["level"] * periods * float(setting("economy_multiplier","1")))
            tax = int(amount * int(setting("tax_percent","5")) / 100)
            con.execute("UPDATE players SET cash=cash+? WHERE user_id=?", (amount-tax, uid))
            con.execute("UPDATE companies SET last_collect=? WHERE id=?", (now, item_id))
            bot.answer_callback_query(call.id, "تم تحصيل الأرباح!")
            bot.send_message(call.message.chat.id, f"🏭 أرباح الشركة: {money(amount-tax)} بعد الضريبة.")
        elif action == "upgrade":
            cost = row["cost"] * row["level"]
            player = con.execute("SELECT cash FROM players WHERE user_id=?", (uid,)).fetchone()
            if player["cash"] < cost:
                bot.answer_callback_query(call.id, f"تحتاج {money(cost)}.", show_alert=True); return
            con.execute("UPDATE players SET cash=cash-? WHERE user_id=?", (cost, uid))
            con.execute("UPDATE companies SET level=level+1,income=income*2 WHERE id=?", (item_id,))
            bot.answer_callback_query(call.id, "تم تطوير الشركة!")
            bot.send_message(call.message.chat.id, f"⬆️ تم تطوير {row['name']} للمستوى {row['level']+1}.")

def show_companies(chat_id, uid):
    with db_lock, connect() as con:
        rows = con.execute("SELECT * FROM companies WHERE owner_id=? ORDER BY id DESC", (uid,)).fetchall()
    if not rows:
        bot.send_message(chat_id, "ما عندك شركات. افتح السوق واضغط عرض الشركات."); return
    for r in rows[:20]:
        periods = min(8, (int(time.time())-r["last_collect"]) // (6*3600))
        ready = r["income"] * r["level"] * periods
        kb = inline([[("💰 تحصيل الأرباح", f"comp:collect:{r['id']}"), ("⬆️ تطوير", f"comp:upgrade:{r['id']}")]])
        bot.send_message(chat_id, f"🏭 {r['name']} | المستوى {r['level']}\nالدخل لكل 6 ساعات: {money(r['income']*r['level'])}\nأرباح جاهزة تقريباً: {money(ready)}", reply_markup=kb)

def show_alliances(chat_id, uid):
    with db_lock, connect() as con:
        mine = con.execute("""SELECT a.* FROM alliances a JOIN alliance_members m ON m.alliance_id=a.id WHERE m.user_id=?""", (uid,)).fetchone()
        rows = con.execute("""SELECT a.id,a.name,a.treasury,a.leader_id,COUNT(m.user_id) members
                              FROM alliances a LEFT JOIN alliance_members m ON m.alliance_id=a.id
                              GROUP BY a.id ORDER BY members DESC LIMIT 10""").fetchall()
    text = "🤝 <b>التحالفات</b>\n"
    if mine: text += f"\nتحالفك: {mine['name']} | الخزينة: {money(mine['treasury'])}\n"
    else: text += "\nما منضم لأي تحالف.\n"
    text += "\nأكبر التحالفات:\n" + ("\n".join(f"• {r['name']} — {r['members']} عضو" for r in rows) if rows else "لا توجد تحالفات.")
    kb = inline([[("➕ إنشاء تحالف", "ally:create"), ("📥 الانضمام لتحالف", "ally:join")],
                 [("💰 إيداع بالخزينة", "ally:deposit"), ("🚪 مغادرة التحالف", "ally:leave")]])
    bot.send_message(chat_id, text, reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data.startswith("ally:"))
def alliance_callbacks(call):
    uid = call.from_user.id
    action = call.data.split(":")[1]
    if action in ("create", "join"):
        pending_trade[uid] = ("ally_create" if action == "create" else "ally_join", None)
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, "أرسل اسم التحالف لإنشائه أو للانضمام إليه. (الاسم فقط)")
        return
    with db_lock, connect() as con:
        membership = con.execute("SELECT * FROM alliance_members WHERE user_id=?", (uid,)).fetchone()
        if action == "leave":
            if not membership: bot.answer_callback_query(call.id, "أنت مو بتحالف."); return
            alliance = con.execute("SELECT leader_id FROM alliances WHERE id=?", (membership["alliance_id"],)).fetchone()
            if alliance and alliance["leader_id"] == uid:
                bot.answer_callback_query(call.id, "قائد التحالف لازم يحله أو ينقل القيادة (غير متاح حالياً).", show_alert=True); return
            con.execute("DELETE FROM alliance_members WHERE user_id=?", (uid,))
            bot.answer_callback_query(call.id, "غادرت التحالف.")
        elif action == "deposit":
            if not membership:
                bot.answer_callback_query(call.id, "انضم لتحالف أولاً.", show_alert=True); return
            pending_trade[uid] = ("ally_deposit", membership["alliance_id"])
            bot.answer_callback_query(call.id)
            bot.send_message(call.message.chat.id, "كم تريد تودع؟ اكتب مبلغاً رقمياً.")
            return

@bot.message_handler(func=lambda m: m.from_user.id in pending_trade, content_types=["text"])
def trade_text(message):
    uid = message.from_user.id
    action, extra = pending_trade.pop(uid)
    text = message.text.strip()
    if action in ("ally_create", "ally_join"):
        name = text[:40]
        with db_lock, connect() as con:
            existing = con.execute("SELECT user_id FROM alliance_members WHERE user_id=?", (uid,)).fetchone()
            if existing:
                bot.reply_to(message, "أنت منضم لتحالف بالفعل."); return
            try:
                if action == "ally_create":
                    cur = con.execute("INSERT INTO alliances(name,leader_id,created_at) VALUES(?,?,?)", (name, uid, int(time.time())))
                    aid = cur.lastrowid
                    con.execute("INSERT INTO alliance_members(alliance_id,user_id,role,joined_at) VALUES(?,?,?,?)", (aid, uid, "قائد", int(time.time())))
                    bot.reply_to(message, f"👑 تم تأسيس التحالف <b>{name}</b>!")
                else:
                    row = con.execute("SELECT id FROM alliances WHERE name=?", (name,)).fetchone()
                    if not row: bot.reply_to(message, "ما لكيت تحالف بهذا الاسم."); return
                    con.execute("INSERT INTO alliance_members(alliance_id,user_id,role,joined_at) VALUES(?,?,?,?)", (row["id"], uid, "عضو", int(time.time())))
                    bot.reply_to(message, f"تم الانضمام إلى التحالف {name}.")
            except sqlite3.IntegrityError:
                bot.reply_to(message, "اسم التحالف مستخدم أو تعذر الانضمام.")
    elif action == "ally_deposit":
        try:
            amount = int(text)
            if amount <= 0 or not change_money(uid, -amount, 0): raise ValueError()
            with db_lock, connect() as con:
                con.execute("UPDATE alliances SET treasury=treasury+? WHERE id=?", (amount, extra))
            bot.reply_to(message, f"أودعت {money(amount)} في خزينة التحالف.")
        except Exception:
            bot.reply_to(message, "مبلغ غير صحيح أو رصيدك غير كافٍ.")

def adventure(chat_id, uid, p):
    outcomes = [
        ("عثرت على صندوق تاجر ضائع", 0.55, 100, 800),
        ("أنقذت قافلة تجارية", 0.50, 150, 1000),
        ("واجهت لصوصاً وخسرت بعض المال", -0.40, 100, 500),
        ("اكتشفت منجماً صغيراً", 0.65, 200, 1200),
        ("تعرضت لعاصفة واضطررت لدفع تكاليف", -0.25, 100, 400),
    ]
    title, sign, lo, hi = random.choice(outcomes)
    amount = int(random.randint(lo, hi) * float(setting("economy_multiplier","1")))
    if sign < 0:
        loss = min(p["cash"], int(amount * abs(sign)))
        change_money(uid, -loss, 0)
        result = f"😓 {title}.\nخسرت {money(loss)}."
    else:
        reward = int(amount * sign)
        change_money(uid, reward, 0)
        with db_lock, connect() as con:
            con.execute("UPDATE players SET xp=xp+35,reputation=reputation+1 WHERE user_id=?", (uid,))
        result = f"🎉 {title}!\nربحت {money(reward)} و35 خبرة."
    bot.send_message(chat_id, "⚔️ <b>نتيجة المغامرة</b>\n\n" + result)

# generic commands and level progression
@bot.message_handler(commands=["id"])
def id_cmd(message):
    bot.reply_to(message, f"معرفك: <code>{message.from_user.id}</code>")

def level_worker():
    while True:
        try:
            with db_lock, connect() as con:
                rows = con.execute("SELECT user_id,level,xp FROM players").fetchall()
                for r in rows:
                    lvl, xp = r["level"], r["xp"]
                    while xp >= lvl * 250:
                        xp -= lvl * 250
                        lvl += 1
                    if lvl != r["level"] or xp != r["xp"]:
                        con.execute("UPDATE players SET level=?,xp=? WHERE user_id=?", (lvl,xp,r["user_id"]))
        except Exception as e:
            print("level worker error:", e)
        time.sleep(60)

def main():
    init_db()
    threading.Thread(target=level_worker, daemon=True).start()
    print("Empire bot started.")
    while True:
        try:
            bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)
        except Exception as e:
            print("Polling error:", e)
            time.sleep(5)

if __name__ == "__main__":
    main()
